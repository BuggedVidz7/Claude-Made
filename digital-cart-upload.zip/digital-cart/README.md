# Digital Cart

A smart-supermarket app: a 3D animated store map, scan-and-go checkout, weekly specials, 55 recipes that add their ingredients to your trolley, and a trolley route that walks you past every item. It installs on a phone like a normal app and works offline.

**Live site:** https://buggedvidz7.github.io/Claude-Made/ (after you switch on GitHub Pages, see below)

## What's inside
- `index.html`: the app screen and styles
- `js/`: the app code (`app.js` screens, `store.js` prices and trolley, `scene.js` 3D map, `scanner.js` barcode scanning)
- `data/`: products, store layout, offers and recipes (plain JSON, easy to edit)
- `vendor/`: the 3D library and barcode library used by the app
- `manifest.webmanifest`, `sw.js`, `icons/`: make it installable and offline-capable

## Run it on your computer
Open a terminal in this folder and run `python3 -m http.server 8000`, then open http://localhost:8000

## Publish it as a website
See the step-by-step in the repo: Settings -> Pages -> Source: **GitHub Actions**, plus the file `.github/workflows/digital-cart-pages.yml`.

Prices and barcodes in `data/products.json` are made-up sample values.
